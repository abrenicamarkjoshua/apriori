<html>
<body>
		
<script src="ddmenu.js" type="text/javascript"></script>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	
	
	<div id="loob">
        
        <div id="contain">
	<img src="images/lpu.png" width="180" height="180" alt="logo"/>
	
	
	</div>
	<br><br><br><br><br><br>
	
	<nav id="ddmenu">
	
	<div class="menu-icon"></div><br><br>

	
        <div  id="border" style="border-style: hidden; height: 8% margin=10%">
        <div id="header" style>
	<center><p>
	<ul>

		 <li class="no-sub"><a class="top-heading" href="index.php">Students Information</a></li>
		 			<li>
            <a class="top-heading" href="#">Examination</a>
			<i class="caret"></i>           
            <div class="dropdown">
                <div class="dd-inner">
                    <div class="column">
                        <h3>Physical</h3>
                        <a href="#">View</a>
                        <a href="#">Add</a>
                        
                        
                    </div>
					 <div class="column">
                        <h3>Dental</h3>
                        <a href="#">View</a>
                        <a href="#">Add</a>
                        
                        
                    </div>
                </div>
            </div>
        </li>
		<li>
            <a class="top-heading" href="#">Records</a>
			<i class="caret"></i>           
            <div class="dropdown">
                <div class="dd-inner">
                    <div class="column">
                        <h3>Medical</h3>
                        <a href="#">View</a>
                        <a href="#">Add</a>
                        
                        
                    </div>
					 <div class="column">
                        <h3>Dental</h3>
                        <a href="#">View</a>
                        <a href="#">Add</a>
                        
                        
                    </div>
                </div>
            </div>
        </li>
		 <li class="no-sub"><a class="top-heading" href="index.php">Check-up Summary</a></li>
		  <li class="no-sub"><a class="top-heading" href="index.php">Refferal</a></li>
		 </ul> 
			
			
			
			
	</p></center>
	</div>
        </div>

<br>
</nav>
	
	<form method = "post" action="insert.php" id="register">
	
	
	Civil Status:<br><br> <br>
	<input type="checkbox" id="radio" name="civilstat" value="Married">Married<br>
	<input type="checkbox" id="radio" name="civilstat" value="Separated">Separated<br>
	<input type="checkbox" id="radio" name="civilstat" value="Divorced">Divorced<br>
	<input type="checkbox" id="radio" name="civilstat" value="Widowed">Widowed<br>
	<input type="checkbox" id="radio" name="civilstat" value="Preffered not to answer">Preffered not to answer<br><br>
	
	
	<p> <input type="submit" id="reg" value="Register"></p>
		</form>
		
		
		<div  id="borderfooter" style="border">
	
		<div  id="footer" >
			
		</div>
		</div>

  </div>
</body>
</html>
<html>
<body>
		
		
		
</body>
</html>