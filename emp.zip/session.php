
<?php
$userid=$_POST
if(($_SESSION['student_id'])){
	$_SESSION['student_id'] =  ;
}



echo"LoL";



?>