<html>	<body>										
													<Input type = "radio" Name ="gender" value= "Female"/>Female </br>
												
											
													<Input type = "radio" Name ="gender" value="Male"/>Male
												
</body></html>