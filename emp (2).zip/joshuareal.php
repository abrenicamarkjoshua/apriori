<?php mysql_connect("localhost", "root", "") or die ("");
		mysql_select_db("clinic");
	
$stud_id=$_GET['student_id'];

						{
						
						
						
	
							
					
$result=mysql_query("select * from student where student_id = ['txtuserid']");

			echo	
                  "$stud_id[student_id]"
                  

                
				                  
				
             
			  ;}
			 ?>

<html>
<form method="post">

Id<input type="text" value="">

</html>

