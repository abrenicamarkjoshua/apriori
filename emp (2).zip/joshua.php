<?php mysql_connect("localhost", "root", "") or die ("");
		mysql_select_db("clinic");
	
$stud_id=$_GET['id'];

						
						
						
						
	
							
					
$result=mysql_query("select * from student where student_id = $stud_id");

	$a=mysql_fetch_array($result);
			 ?>

<html>
<form method="post">

Contact Number<input type="text" name="stud" value="<?php echo $a['studentno'];?>">
Guardian Number<input type="text" name="guard" value="<?php ?>">
<br><input type="submit" value="Update" name="btn" />

</html>
<?php
	if($_POST){
	
	if($_POST['stud']==="" && $_POST['guard']==="" || $_POST['stud']===""  || $_POST['guard']==="" ){
	echo"
		<script>
		alert('error');
		</script>
	
	";
	
	}else{
	mysql_query("update student set studentno='$_POST[stud]', guardianno='$_POST[guard]' where student_id='$stud_id'");
	echo"
		<script>
		alert('Contact Updated');
		window.location.href ='home.php';
		</script>
	
	";
	}
	
	

}
?>

