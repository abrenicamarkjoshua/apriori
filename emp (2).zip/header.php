<?php 
require_once 'mainmodule.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		Clinic management system
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel = "stylesheet" href = "css/pure-min.css"/>
    <link rel="stylesheet" href="css/grids-responsive-min.css">

	<link rel = "stylesheet" href = "css/main.css"/>
</head>
<body>
<div class = "">
	