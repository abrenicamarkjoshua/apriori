<?php

	mysql_connect("localhost", "root", "") or die ("");
	mysql_select_db("clinic");
	mysql_query("UPDATE student SET ('student_id,lastname,firstname,middlename,birthday,gender,studentno,guardianno,course,civilstat')")

?>