// Copyright 2008-2015 Monetate, Inc.
// 2015-05-12T13:03:47Z t1431368962 nop.js
(function(){function a(){}var b=["monetate","a"],c=this;!(b[0]in c)&&c.execScript&&c.execScript("var "+b[0]);for(var d;b.length&&(d=b.shift());)!b.length&&void 0!==a?c[d]=a:c=c[d]?c[d]:c[d]={};})();
if(this.monetate){monetate.a()}