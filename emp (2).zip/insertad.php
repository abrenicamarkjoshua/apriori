<?php

		mysql_connect("localhost", "root", "") or die ("");
		mysql_select_db("clinic");
	$admin_id = $_POST ['admin_id'];
	$admin_pass = $_POST ['password'];
	$repass = $_POST['repasswords'];
	
	if($admin_id   &&  $admin_pass)  {
	
		if($admin_pass == $repass){
		mysql_query("INSERT INTO admin(admin_id,admin_pass) VALUES 
		('$admin_id','$admin_pass')");
		
		echo "<script type='text/javascript'>

alert('Account created.');
window.location.href ='index.php';
</script>
";
		
		}else {
		echo "<script type='text/javascript'>

alert('Passwords Mismatch.'); 
window.location.href ='regad.php';
</script>
";
		}
		}
			
			else{
			echo "<script type='text/javascript'>

alert('May walang laman.'); 
window.location.href ='regad.php';
</script>
";
			}
	
?>