<html >
  <head>
    <meta charset="UTF-8">
    <title>Login</title>
    
    
    
    	
	<script src="ddmenu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" href="css/style.css" type="text/css"/>

	<div id="contain">
	<img src="../images/lpucc.png" width="1200" height="130" alt="logo"/>
	 
	</div>
        
    
    
    
  </head>

  <body>

    <div class="container">

  <div id="login-form">

    <h3>Login</h3>

    <fieldset>

      
	  <form method="post" action="../login.php">

        <input type="text" placeholder="UserID" name="txtuserid"><br>
        <input type="password" placeholder="Password" name="txtpassword"><br>

			<input type="submit" value="Login">

        

      </form>

    </fieldset>
	
  </div>

</div>
    
	
    
    
    
    
  </body>
</html>

